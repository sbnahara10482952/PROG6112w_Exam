import static org.junit.Assert.*;
import org.junit.Test;

public class SalesGUITests {

    @Test
    public void CalculateTotalSalesPrice_CalculatedSuccessfully() {
        IProduct mt = new Product();
        double result = mt.CalculateTotalSalesPrice(2, 100);
        assertEquals(500, result, 0.01); // 2 * 100 + VAT
    }
