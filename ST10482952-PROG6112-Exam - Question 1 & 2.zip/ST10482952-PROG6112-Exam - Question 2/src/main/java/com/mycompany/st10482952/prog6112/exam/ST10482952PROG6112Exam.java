package com.mycompany.st10482952.prog6112.exam;

/**
 *
 * @author Sibusiso Nahara
 * Student Number: ST10482952
 * Lecturer: Simon Rikhotso
 * Programming 1B - Summative Examination
 * Question 2
 */

public class ST10482952PROG6112Exam {

    public String ProductName;
    public String minSales;
    public String avgSales;
    public String maxSales;

    public ST10482952PROG6112Exam(String ProductName, String minSales, String avgSales, String maxSales){
        this.ProductName = ProductName;
        this.minSales = minSales;
        this.avgSales = avgSales;
        this.maxSales = maxSales;
    }

}
