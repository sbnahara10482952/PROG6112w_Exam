import static org.junit.Assert.*;
import org.junit.Test

/**
 *
 * @author Sibusiso Nahara
 * Student Number: ST10482952
 * * Lecturer: Simon Rikhotso
 * Programming 1B - Summative Examination
 * Question 1
 */
        
public class ProductTest {
    
    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales(){
        ISales mt = new Sales();
        int[] productSales = {300, 150, 700};
        int result = mt.TotalYearSales(sales);
        assertEquals(1150, result);
    }
    
    @Test
    public void TopYearSales_ReturnsTopYear(){
        ISales mt = new Sales();
                String[] sales = {"YEAR1", "YEAR2"};
        int[] totals = {6200, 6300};
        String result = mt.TopYear(year, totals);
        assertEquals("YEAR1", result);

    }
}
    
    