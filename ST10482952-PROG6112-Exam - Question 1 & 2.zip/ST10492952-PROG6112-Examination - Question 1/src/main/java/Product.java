
/**
 *
 * @author Sibusiso Nahara
 * Student Number: ST10482952
 * * Lecturer: Simon Rikhotso
 * Programming 1B - Summative Examination
 * Question 1
 */

public class Product {
        
    public int TotalYearSales(int[] productSales) {
        int total = 0;
        for (int sale : productSales) {
            total += sale;
        }
        return total;
    }

    
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        for (int i = 1; i < totalSales.length; i++) {
            if(totalSales[i] > totalSales[topIndex]) {
                topIndex = i;
            }
        }
        return movies[topIndex];
    }
}

    
    

