package com.mycompany.st10492952.prog6112.examination;

/**
 *
 * @author Sibusiso Nahara
 * Student Number: ST10482952
 * Lecturer: Simon Rikhotso
 * Programming 1B - Summative Examination
 * Question 1
 */
public class ST10492952PROG6112Examination {

    public static void main(String[] args) {
        
        // Single Dimensional Array for Movie Names
        String[] sales = {"YEAR1", "YEAR2"};

        // Two Dimensional Array for Product Sales for Quarter 1, 2, & 3
        int[][] productSales = {
                {300, 500, 700},
                {250, 200, 600}
        };

        // Store Total Sales
        int[] totalSales = new int[sales.length];

       IProduct mt = new Product();

        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("--------------------------------------------");
        System.out.println("PRODUCT\t\tQ1\tQ2\tQ3\tTotal Sales");

        for(int i = 0; i < sales.length; i++) {
            totalSales[i] = mt.TotalYearSales(productSales[i]);
            System.out.println(sales[i] + "\t" +
                    productSales[i][0] + "\t" + productSales[i][1] + "\t" + productSales[i][2] + "\t" + totalSales[i]);
        }

        // Determine Top Year
        String topYear = mt.TopYear(sales, totalSales);
        System.out.println("\nTop Performing Product: " + topYear);
    }
}
