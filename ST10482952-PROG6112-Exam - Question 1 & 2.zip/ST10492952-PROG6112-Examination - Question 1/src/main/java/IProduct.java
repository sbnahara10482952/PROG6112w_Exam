
/**
 *
 * @author Sibusiso Nahara
 * Student Number: ST10482952
 * Lecturer: Simon Rikhotso
 * Programming 1B - Summative Examination
 * Question 1
 */

public interface IProduct {
    int TotalProductSales(int[] yearSales);
    String TopYear(String[] sales, int[] totalSales);
}
